#include "trajectory.hpp"

#include <algorithm>
#include <array>
#include <cmath>

#include "engine/engine.hpp"
#include "engine/timeline.hpp"
#include "ccTypes.h"
#include "checkpoint/checkpoint.hpp"
#include "physics/collisions.hpp"
#include "physics/object.hpp"
#include "replay/macro.hpp"
#include "config/config.hpp"
#include "util/crash_log.hpp"

#ifdef SILICATE_PROTECT
#include "VMProtect/VMProtectSDK.h"
#endif

using namespace geode::prelude;

static cocos2d::ccColor4F toCocosColor(const float colors[4]) {
    return {colors[0], colors[1], colors[2], colors[3]};
}

static bool isHoldingJump(PlayerObject* player) {
    if (!player) return false;
    const auto it =
        player->m_holdingButtons.find(static_cast<int>(PlayerButton::Jump));
    return it != player->m_holdingButtons.end() && it->second;
}

static cocos2d::CCRect usingWidth(const cocos2d::CCRect& rect, float width) {
    return {rect.origin.x + width, rect.origin.y + width,
            rect.size.width - width * 2.f,
            rect.size.height - width * 2.f};
}

static void drawRect(CCDrawNode* node, CCRect& rect, ccColor4F color,
                     float width) {
    node->drawRect(rect, {0, 0, 0, 0}, width, color);
}

static void drawRotatedRect(CCDrawNode* node, CCRect& rect, float angle,
                            ccColor4F color, float width) {
    std::array<CCPoint, 4> vertices = {
        CCPoint{rect.getMinX(), rect.getMinY()},
        CCPoint{rect.getMaxX(), rect.getMinY()},
        CCPoint{rect.getMaxX(), rect.getMaxY()},
        CCPoint{rect.getMinX(), rect.getMaxY()},
    };
    const CCPoint center{rect.getMidX(), rect.getMidY()};
    const float radians = -CC_DEGREES_TO_RADIANS(angle);
    for (auto& vertex : vertices)
        vertex = vertex.rotateByAngle(center, radians);
    node->drawPolygon(vertices.data(), vertices.size(), {0, 0, 0, 0}, width,
                      color);
}

static uint64_t packPlayerFlags(PlayerObject* p) {
    uint64_t flags = 0;
    int bit = 0;
    auto set = [&](bool v) { if (v) flags |= (uint64_t(1) << bit); ++bit; };
    set(p->m_isShip);   set(p->m_isBird);   set(p->m_isDart);
    set(p->m_isSwing);  set(p->m_isBall);   set(p->m_isSpider);
    set(p->m_isRobot);  set(p->m_isUpsideDown); set(p->m_isDead);
    set(p->m_isOnGround2); set(p->m_isSideways); set(p->m_isDashing);
    set(p->m_isAccelerating); set(p->m_holdingLeft); set(p->m_holdingRight);
    set(p->m_jumpBuffered); set(p->m_isPlatformer); set(p->m_isGoingLeft);
    set(p->m_maybeIsBoosted); set(isHoldingJump(p));
    return flags;
}

static size_t hashTrajectoryCategories() {
    size_t h = 0;
    for (const auto& [key, state] : GrapeSettings::get()->trajectory.categories) {
        size_t e = std::hash<int>{}(key);
        e = e * 31 + (state.enabled ? 1u : 0u);
        for (const float c : state.colors) e = e * 31 + std::hash<float>{}(c);
        h ^= e + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
    }
    const auto& settings = GrapeSettings::get()->trajectory;
    h ^= std::hash<bool>{}(settings.straightEnabled);
    for (float color : settings.straightColor)
        h ^= std::hash<float>{}(color) + 0x9e3779b9 + (h << 6) + (h >> 2);
    return h;
}

#ifdef GEODE_IS_MOBILE
static double trajectoryPredictionTps(double actualTps,
                                      double overriddenTps = 0.0) {
    if (std::isfinite(overriddenTps) && overriddenTps > 0.0) {
        return overriddenTps;
    }
    if (!std::isfinite(actualTps) || actualTps <= 0.0) actualTps = 240.0;

    return std::clamp(actualTps, 240.0, 480.0);
}
#endif

Trajectory::Signature Trajectory::computeSignature(GJBaseGameLayer* pl) {
    Signature s;
    s.frame = GrapeEngine::get()->timeline().getFrame();

    auto fillPlayer = [](float out[7], uint64_t& flags, PlayerObject* p) {
        const CCPoint pos = p->getPosition();
        out[0] = pos.x;            out[1] = pos.y;
        out[2] = p->getRotation(); out[3] = p->m_yVelocity;
        out[4] = p->m_platformerXVelocity;
        out[5] = p->m_gravityMod;  out[6] = p->m_vehicleSize;
        flags  = packPlayerFlags(p);
    };

    if (pl->m_player1) fillPlayer(s.p1, s.p1flags, pl->m_player1);
    if (pl->m_player2) fillPlayer(s.p2, s.p2flags, pl->m_player2);

    s.timeWarp    = pl->m_gameState.m_timeWarp;
    s.cameraZoom  = pl->m_gameState.m_cameraZoom;
    s.width       = static_cast<float>(m_state->m_width->inner());
    s.length      = static_cast<float>(m_state->m_length->inner());
    s.maxSteps    = GrapeSettings::get()->trajectory.maxSteps;

    uint32_t b = 0;
    int bit = 0;
    auto setb = [&](bool v) { if (v) b |= (uint32_t(1) << bit); ++bit; };
    setb(m_state->m_enabled->inner());
    setb(pl->m_gameState.m_isDualMode);
    setb(pl->m_isPlatformer);
    setb(pl->m_levelSettings->m_twoPlayerMode);
    setb(m_p1Holding);
    setb(m_p2Holding);
    setb(pl->m_player1 != nullptr);
    setb(pl->m_player2 != nullptr);
    s.boolPack = b;

    s.categoriesHash = hashTrajectoryCategories();
    return s;
}

int Trajectory::getPredictionLength(GJBaseGameLayer* pl) {
    auto bot = GrapeEngine::get();
    if (!pl) return 0;

    auto& ts = GrapeSettings::get()->trajectory;
#ifdef GEODE_IS_MOBILE
    const double timeWarp = std::max(
        std::abs(static_cast<double>(pl->m_gameState.m_timeWarp)), 0.001);
    const double length = std::clamp(ts.length, 0.0, 60.0);
    int steps = static_cast<int>(
        length * trajectoryPredictionTps(bot->timeline().getTps()) /
        timeWarp);
#else
    int steps = static_cast<int>(
        ts.length * std::max(bot->timeline().getTps(), 240.0) /
        pl->m_gameState.m_timeWarp);
#endif

    if (ts.maxSteps > 0)
        steps = std::min(steps, ts.maxSteps);

    return steps;
}

bool Trajectory::iterate(GJBaseGameLayer* pl, PlayerObject* player, int mode,
                         float* colors, int& stepCount,
                         PredictionConfig config) {
    const CCPoint prevPos = player->getPosition();

    auto& updater = GrapeEngine::get()->timeline();
#ifdef GEODE_IS_MOBILE
    const double predictionTps = trajectoryPredictionTps(
        updater.getTps(), config.m_overridenTPS);
    const float physicsDt = static_cast<float>(1.0 / predictionTps);
#else
    const float physicsDt = updater.getPhysicsDt();
#endif
    const float timeWarp  = updater.getTimeWarp();

    pl->m_gameState.m_totalTime    += physicsDt;
    pl->m_gameState.m_unkDouble3   += physicsDt / timeWarp;
    pl->m_gameState.m_currentProgress++;
    pl->m_gameState.m_unkUint5     += static_cast<int>(roundf(timeWarp * 1000.0f));

    player->m_totalTime += physicsDt;

    float playerSpeed = *reinterpret_cast<float*>(&pl->m_gameState.m_timeModRelated);
    if (playerSpeed != 0.0f) {
        pl->m_gameState.m_timeModRelated  = 0;
        pl->m_gameState.m_timeModRelated2 = 0;
        player->updateTimeMod(playerSpeed, true);
    }

    player->m_collisionLogTop->removeAllObjects();
    player->m_collisionLogBottom->removeAllObjects();
    player->m_collisionLogLeft->removeAllObjects();
    player->m_collisionLogRight->removeAllObjects();

    if ((m_deadP1 && (mode & TrajectoryMode::Player1) != 0) ||
        (m_deadP2 && (mode & TrajectoryMode::Player2) != 0)) {
        if (stepCount > 1) drawHitbox(pl, player);
        return true;
    }

    if (!m_actions.empty()) {
        for (auto& action : m_actions) {
            if (action.m_delay == 0) {
                action.m_func();
                action.m_executed = true;
            } else {
                --action.m_delay;
            }
        }
        std::erase_if(m_actions, [](const auto& a) { return a.m_executed; });
    }

#ifdef GEODE_IS_MOBILE
    const float delta = physicsDt * 60.0f;
#else
    const float delta = (config.m_overridenTPS == 0.0)
                            ? m_delta
                            : static_cast<float>(
                                  (1.0 / config.m_overridenTPS) * 60.0);
#endif

    player->m_playEffects = false;
    player->update(delta);
    player->m_unkUnused3  = player->getRotation();
    player->updateRotation(delta);
    player->m_shipRotation = player->getPosition();

    // Keep the ring-jump buffer alive while the jump button is held, so a
    // simulated player can activate an orb it reaches mid-flight -- exactly like
    // a real held/buffered input. The initial pushButton only sets these flags
    // for a moment, so without this the simulation is blind to any orb more than
    // a step away, which made the pathfinder ignore orbs and fall into pits.
    // Both flags are read ONLY by phys::ringJump, so tying them to the held
    // state has no other physics side effects.
    {
        const auto held = player->m_holdingButtons.find(
            static_cast<int>(PlayerButton::Jump));
        const bool holdingJump =
            held != player->m_holdingButtons.end() && held->second;
        player->m_stateJumpBuffered = holdingJump;
        player->m_stateRingJump2 = holdingJump;
    }

    if (pl->checkCollisions(player, delta, false) == 1)
        hasDied(player);

    phys::checkSpawnObjects(pl, player);
    pl->m_effectManager->postCollisionCheck();

    const float width = m_state->m_width->inner() / pl->m_gameState.m_cameraZoom;
    m_node->drawSegment(
        prevPos, player->getPosition(), width, toCocosColor(colors));

    ++stepCount;
    return false;
}

TrajectoryPlayerData Trajectory::runPrediction(GJBaseGameLayer* pl,
                                               PlayerObject* player,
                                               PlayerObject* other, int mode,
                                               float* colors, bool both,
                                               PredictionConfig config) {
    auto   bot       = GrapeEngine::get();
    int iterations = getPredictionLength(pl);
    if (config.m_maxLength > 0)
        iterations = std::min(iterations, config.m_maxLength);

    const int playerMask = (player == m_fakePlayer1) ? TrajectoryMode::Player1
                                                      : TrajectoryMode::Player2;
    const bool dualBoth  = both && pl->m_gameState.m_isDualMode;
    const float width    = m_state->m_width->inner() / pl->m_gameState.m_cameraZoom;

    std::array<PlayerObject*, 2> activePlayers = {player, other};
    const int activeCount = dualBoth ? 2 : 1;

#ifdef GEODE_IS_MOBILE
    {
#else
    if (bot->isRecording()) {
#endif
        for (int i = 0; i < activeCount; ++i) {
            PlayerObject* plr = activePlayers[i];
            switch (mode & CLICK_MASK) {
                case TrajectoryMode::Hold:
                    plr->pushButton(PlayerButton::Jump);
                    break;
                case TrajectoryMode::Swift:
                    plr->pushButton(PlayerButton::Jump);
                    plr->releaseButton(PlayerButton::Jump);
                    break;
                case TrajectoryMode::Release:
                    plr->releaseButton(PlayerButton::Jump);
                    plr->m_jumpBuffered = false;
                    break;
            }

            if (pl->m_levelSettings->m_platformerMode) {
                switch (mode & DIRECTION_MASK) {
                    case TrajectoryMode::Left:
                        plr->releaseButton(PlayerButton::Right);
                        plr->pushButton(PlayerButton::Left);
                        break;
                    case TrajectoryMode::Right:
                        plr->releaseButton(PlayerButton::Left);
                        plr->pushButton(PlayerButton::Right);
                        break;
                    default:
                        plr->releaseButton(PlayerButton::Left);
                        plr->releaseButton(PlayerButton::Right);
                        break;
                }
            }
        }
    }

    for (int i = 0; i < activeCount; ++i) {
        PlayerObject* plr = activePlayers[i];
        const CCPoint pos = plr->getPosition();
        m_node->drawSegment(pos, plr->getPosition(), width,
                            toCocosColor(colors));
    }

    bool breakP1 = false;
    bool breakP2 = false;
    int stepP1 = 0;
    int stepP2 = 0;
    int trajectoryInputIndex = bot->macro().getInputIndex();
    const auto& inputs = bot->macro().m_actionAtom.m_actions;
#ifdef GEODE_IS_MOBILE
    const double macroTps = std::max(bot->timeline().getTps(), 1.0);
    const double predictionTps = trajectoryPredictionTps(
        macroTps, config.m_overridenTPS);
#endif

    int predCount = 0;
    float minY = player->getObjectRect().getMinY();
    float maxY = player->getObjectRect().getMaxY();
    for (int i = 0; i < iterations; ++i) {
        if (bot->isPlaying()) {
#ifdef GEODE_IS_MOBILE
            const uint64_t frame = bot->timeline().getFrame() +
                static_cast<uint64_t>(
                    std::floor(i * macroTps / predictionTps));
#else
            const uint64_t frame = bot->timeline().getFrame() + i;
#endif
            while (trajectoryInputIndex < static_cast<int>(inputs.size()) &&
                   inputs[trajectoryInputIndex].m_frame <= frame) {
                const auto& input = inputs[trajectoryInputIndex];
                PlayerObject* p   = input.m_player2 ? m_fakePlayer2 : m_fakePlayer1;
                PlayerObject* op  = input.m_player2 ? m_fakePlayer1 : m_fakePlayer2;

                if (input.m_holding) {
                    p->pushButton(static_cast<PlayerButton>(input.m_type));
                    if (dualBoth) op->pushButton(static_cast<PlayerButton>(input.m_type));
                } else {
                    p->releaseButton(static_cast<PlayerButton>(input.m_type));
                    if (dualBoth) op->releaseButton(static_cast<PlayerButton>(input.m_type));
                }
                ++trajectoryInputIndex;
            }
        }

        // Delayed-input probe: flip the active player's jump at the requested
        // step so callers can evaluate "wait, then act" plans. Only meaningful
        // when we drive the input ourselves (recording / not replaying macro).
        if (config.m_flipAtStep >= 0 && i == config.m_flipAtStep &&
            !bot->isPlaying()) {
            const bool toHold = (mode & CLICK_MASK) != TrajectoryMode::Hold;
            for (int a = 0; a < activeCount; ++a) {
                PlayerObject* plr = activePlayers[a];
                if (toHold) {
                    plr->pushButton(PlayerButton::Jump);
                } else {
                    plr->releaseButton(PlayerButton::Jump);
                    plr->m_jumpBuffered = false;
                }
            }
        }

        if (!breakP1) {
            breakP1 =
                iterate(pl, player, mode | playerMask, colors, stepP1, config);
            const auto rect = player->getObjectRect();
            minY = std::min(minY, rect.getMinY());
            maxY = std::max(maxY, rect.getMaxY());
            ++predCount;
        }
        if (dualBoth && !breakP2) {
            breakP2 = iterate(pl, other, mode | TrajectoryMode::Player2,
                              colors, stepP2, config);
        }
    }

    return {
        .position    = player->getPosition(),
        .hitbox      = player->getObjectRect(),
        .innerHitbox = player->getObjectRect(0.3, 0.3),
        .rotation    = player->getRotationX(),
        .p1          = (mode & TrajectoryMode::Player1) != 0,
        .holding     = (mode & TrajectoryMode::Hold) != 0,
        .score       = predCount,
        .minY        = minY,
        .maxY        = maxY,
    };
}

TrajectoryPlayerData Trajectory::simulate(GJBaseGameLayer* pl, bool p1,
                                          int mode, bool clickBothPlayers,
                                          PredictionConfig config) {
    auto& ts = GrapeSettings::get()->trajectory;

    PlayerObject* player         = p1 ? m_fakePlayer1 : m_fakePlayer2;
    PlayerObject* realPlayer     = p1 ? pl->m_player1  : pl->m_player2;
    PlayerObject* otherPlayer    = p1 ? m_fakePlayer2  : m_fakePlayer1;
    PlayerObject* otherReal      = p1 ? pl->m_player2  : pl->m_player1;

    const bool isLeft        = (mode & TrajectoryMode::Left)  != 0;
    const bool isRight       = (mode & TrajectoryMode::Right) != 0;
    const bool isDirectionless = !(isLeft || isRight);
    const bool holdingDir    = (isLeft  && realPlayer->m_holdingLeft)  ||
                               (isRight && realPlayer->m_holdingRight) ||
                               (isDirectionless && !realPlayer->m_holdingLeft &&
                                                   !realPlayer->m_holdingRight);
    const bool holdingOpp    = (isLeft  && realPlayer->m_holdingRight) ||
                               (isRight && realPlayer->m_holdingLeft);

    const int platformerMask = pl->m_isPlatformer ? TrajectoryMode::Platformer : 0;

    if (!config.m_bypassConfig) {
        auto& cats = ts.categories;
        const bool mainEnabled   = cats[mode | platformerMask].enabled;
        const bool followEnabled = cats[(mode & CLICK_MASK) | TrajectoryMode::FollowPlayer |
                                        platformerMask].enabled && holdingDir;
        const bool oppEnabled    = cats[(mode & CLICK_MASK) | TrajectoryMode::FollowOpposite |
                                        platformerMask].enabled && holdingOpp;
        if (!(mainEnabled || followEnabled || oppEnabled)) return {};
    }

    const GJGameState savedState = pl->m_gameState;
    EffectManagerState ems;
    pl->m_effectManager->saveToState(ems);

    auto syncPlayer = [](PlayerObject* fake, PlayerObject* real) {
        fake->copyAttributes(real);
        fake->m_maybeReducedEffects = true;
        SavedPlayerCheckpoint cp = SavedPlayerCheckpoint::create(real);
        cp.apply(fake);
        fake->setPosition(real->m_position);
        fake->setRotation(real->getRotation());
    };

    syncPlayer(player, realPlayer);
    if (clickBothPlayers && otherReal)
        syncPlayer(otherPlayer, otherReal);

    m_deadP1 = false;
    m_deadP2 = false;

    const bool holding = realPlayer->m_isDart
                             ? isHoldingJump(realPlayer)
                             : (p1 ? m_p1Holding : m_p2Holding);
    const bool current =
        (holding && (mode & CLICK_MASK) == TrajectoryMode::Hold) ||
        (!holding && (mode & CLICK_MASK) == TrajectoryMode::Release);
    std::array<float, 4> trajectoryColors =
        current ? std::array<float, 4>{0.f, 1.f, 0.f, 1.f}
                : std::array<float, 4>{0.f, 1.f, 1.f, 1.f};
    float* colors = trajectoryColors.data();
    auto predicted = runPrediction(pl, player, otherPlayer, mode, colors,
                                   clickBothPlayers, config);

    player->setVisible(false);
    otherPlayer->setVisible(false);

    deactivateAllRemembered();

    pl->m_gameState = savedState;
    pl->m_effectManager->loadFromState(ems);

    return predicted;
}

void Trajectory::update(GJBaseGameLayer* pl) {
    if (!pl || pl != m_layer)
        return;
    m_fakePlayer1->setVisible(false);
    m_fakePlayer2->setVisible(false);

    if (auto lel = LevelEditorLayer::get();
        lel && lel->m_playbackMode == PlaybackMode::Not)
        return;

    if (!m_state->m_enabled->inner()) {
        m_node->setVisible(false);
        return;
    }

    m_node->setVisible(true);

    const Signature sig = computeSignature(pl);
    const bool needsRebuild = !m_calculated || !(sig == m_lastSignature);

    if (!needsRebuild) goto applyLayoutColors;

    {
#ifdef GEODE_IS_MOBILE
        crash_log::breadcrumb("Trajectory prediction");
#endif
        m_drawing = true;
        m_node->clear();

        auto& bot  = *GrapeEngine::get();
        m_lastFrame = bot.timeline().getFrame();
        m_delta     = bot.timeline().getPhysicsDt() * 60.0f;

        m_fakePlayer1->setVisible(false);
        if (pl->m_player2) m_fakePlayer2->setVisible(false);

        const bool notTwoPlayer = !pl->m_levelSettings->m_twoPlayerMode;
        const auto predictPlayer = [&](bool p1, bool both) {
            auto* player = p1 ? pl->m_player1 : pl->m_player2;
            const float originX = player->getPositionX();
            float straightX = originX;
            const auto predict = [&](int mode) {
                const auto result = simulate(pl, p1, mode, both);
                if (result.score > 0) {
                    if (std::abs(result.position.x - originX) >
                        std::abs(straightX - originX))
                        straightX = result.position.x;
                }
            };

            predict(TrajectoryMode::Hold);
            predict(TrajectoryMode::Swift);
            predict(TrajectoryMode::Release);
            if (pl->m_isPlatformer) {
                for (int direction : {0, static_cast<int>(TrajectoryMode::Left),
                                      static_cast<int>(TrajectoryMode::Right)}) {
                    predict(TrajectoryMode::Hold | direction);
                    predict(TrajectoryMode::Swift | direction);
                    predict(TrajectoryMode::Release | direction);
                }
            }

            auto& settings = GrapeSettings::get()->trajectory;
            if (player && player->m_isDart && settings.straightEnabled) {
                const float width = m_state->m_width->inner() /
                                    pl->m_gameState.m_cameraZoom;
                const auto origin = player->getPosition();
                m_node->drawSegment(origin, {straightX, origin.y}, width,
                    toCocosColor(settings.straightColor.data()));
            }
        };

        if (pl->m_player1) {
            predictPlayer(true, notTwoPlayer);

            m_fakePlayer1->setVisible(false);
            if (pl->m_player2) m_fakePlayer2->setVisible(false);
        }

        if (pl->m_player2 && pl->m_gameState.m_isDualMode &&
            pl->m_levelSettings->m_twoPlayerMode) {
            predictPlayer(false, false);
        }

        m_calculated    = true;
        m_lastSignature = sig;
        m_drawing       = false;
    }

#ifdef GEODE_IS_MOBILE
    crash_log::breadcrumb("Trajectory idle");
#endif

applyLayoutColors:
    auto& updater = GrapeEngine::get()->timeline();
    if (!updater.m_layoutMode->inner() || LevelEditorLayer::get()) return;

    constexpr std::array<int, 5> colorIds = {1000, 1001, 1009, 1013, 1014};
    for (int colorId : colorIds) {
        ColorAction* action = pl->m_effectManager->getColorAction(colorId);
        if (!action) continue;

        switch (colorId) {
            case 1000: {
                auto& col = GrapeSettings::get()->layoutBgColor;
                action->m_color = {static_cast<GLubyte>(col[0] * 255),
                                   static_cast<GLubyte>(col[1] * 255),
                                   static_cast<GLubyte>(col[2] * 255)};
                break;
            }
            case 1001:
            case 1009: {
                auto& col = GrapeSettings::get()->layoutGroundColor;
                action->m_color = {static_cast<GLubyte>(col[0] * 255),
                                   static_cast<GLubyte>(col[1] * 255),
                                   static_cast<GLubyte>(col[2] * 255)};
                break;
            }
            default:
                action->m_color = {40, 125, 255};
                break;
        }
    }
}

void Trajectory::drawHitbox(GJBaseGameLayer* pl, PlayerObject* player) {
    const float width =
        m_state->m_width->inner() / pl->m_gameState.m_cameraZoom;
    CCRect rect = usingWidth(player->getObjectRect(), width);
    CCRect inner = usingWidth(player->getObjectRect(.3f, .3f), width);
    auto& settings = GrapeSettings::get()->hitboxes;
    using Type = GrapeSettings::HitboxSettings::Type;
    const auto color = [&](Type type) {
        return toCocosColor(settings.categories[type].colors.data());
    };

    drawRotatedRect(m_node, rect, player->getRotation(),
                    color(Type::PlayerRotated), width);
    drawRect(m_node, rect, color(Type::Player), width);
    drawRect(m_node, inner, color(Type::PlayerInner), width);
}

bool Trajectory::playerHasActivated(PlayerObject* player,
                                    EnhancedGameObject* object) {
    if (!object || object->m_isMultiActivate) return false;
    if (player == m_fakePlayer1)
        return m_activatedObjectsP1.contains(reinterpret_cast<uintptr_t>(object));
    if (player == m_fakePlayer2)
        return m_activatedObjectsP2.contains(reinterpret_cast<uintptr_t>(object));
    return false;
}

bool Trajectory::realPlayerHasActivated(PlayerObject* player,
                                        EnhancedGameObject* object) {
    if (!object) return false;
    if (!isFakePlayer(player))
        return phys::hasBeenActivatedByPlayer(player, object);

#ifdef GEODE_IS_MOBILE
    auto* pl = m_layer;
#else
    auto* pl = GJBaseGameLayer::get();
#endif
    if (!pl) return false;
    PlayerObject* realPlayer = (player == m_fakePlayer1) ? pl->m_player1 : pl->m_player2;
    if (!realPlayer) return false;
    return phys::hasBeenActivatedByPlayer(realPlayer, object);
}

static void* RingObject_spawnCircle_orig = nullptr;

void RingObject_spawnCircle(RingObject* self) {
    auto func = reinterpret_cast<void (*)(RingObject*)>(RingObject_spawnCircle_orig);
    if (!GrapeEngine::get()->trajectory().drawing()) func(self);
}
