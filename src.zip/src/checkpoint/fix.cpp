//
// Created by peony on 29.10.2024.
//

#include "fix.hpp"

#include <Geode/Geode.hpp>
#include <algorithm>
#include <vector>

#include "checkpoint/checkpoint.hpp"

using namespace geode::prelude;

#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/UILayer.hpp>

#include "engine/engine.hpp"
#include "engine/timeline.hpp"
#include "replay/macro.hpp"

bool checkpointPlacementBlocked(PlayLayer* pl) {
    if (!pl) return false;
    if (pl->m_playerDied) return true;
    if (pl->m_player1 && pl->m_player1->m_isDead) return true;
    if (pl->m_player2 && pl->m_player2->m_isDead) return true;
    return false;
}

#ifdef GEODE_IS_MOBILE
struct GrapeUILayer : Modify<GrapeUILayer, UILayer> {
    void onCheck(CCObject* sender) {
        auto* pl = PlayLayer::get();
        // Swallow the button while dead instead of placing a checkpoint: the
        // saved frame/input index would not match anything the run played
        // through and the macro desyncs on restore.
        if (GrapeEngine::get()->isEnabled() &&
            checkpointPlacementBlocked(pl)) {
            return;
        }
        UILayer::onCheck(sender);
    }
};
#endif

// taken from https://stackoverflow.com/a/60971856
template <std::ranges::range R>
static constexpr auto to_vector(R&& r) {
    using elem_t = std::decay_t<std::ranges::range_value_t<R>>;
    return std::vector<elem_t>{r.begin(), r.end()};
}

SavedCheckpoint PracticeFix::createCheckpoint(CheckpointObject* obj,
                                              uint64_t attemptStartFrame) {
    if (auto pl = PlayLayer::get(); pl) {
        SavedCheckpoint checkpoint = {
            .m_player1 = SavedPlayerCheckpoint::create(pl->m_player1),
            .m_player2 = SavedPlayerCheckpoint::create(pl->m_player2),
            .m_checkpoint = obj,
            .m_stackSize = m_platformerCheckpoints.size(),
            .m_attemptStartFrame = attemptStartFrame,
            .m_frame = GrapeEngine::get()->timeline().getFrame(),
            .m_replayInputIndex = GrapeEngine::get()->macro().m_inputIndex,
            .m_seedState = GrapeEngine::get()->macro().getCurrentRandomState(),
            .m_shakeRandomState = GrapeEngine::get()->macro().m_shakeRandomState,
            .m_teleportRandomState =
                GrapeEngine::get()->macro().m_teleportRandomState,
            .m_tps = GrapeEngine::get()->timeline().m_tps->inner(),
            .m_timewarpTime = GrapeEngine::get()->timeline().m_timewarpTime,
            .m_persistentItemMap =
                pl->m_effectManager->m_persistentItemCountMap,
            .m_varianceValues = pl->m_varianceValues,
            .m_calcNonEffectObjects = pl->m_calcNonEffectObjects,
            .m_calcNonEffectObjectsSize = pl->m_calcNonEffectObjectsSize,
            .m_brokenObjects = this->m_brokenObjects,
            .m_advRandStates = to_vector(
                m_advancedRandom | std::views::transform([](SavedAdvRand& s) {
                    return *s.m_randomState;
                })),
        };

        return checkpoint;
    }

    return SavedCheckpoint{};
}

void PracticeFix::applyCheckpoint(SavedCheckpoint& cp) {
    if (auto pl = PlayLayer::get(); pl) {
        cp.m_player1.apply(pl->m_player1);
        cp.m_player2.apply(pl->m_player2);

        pl->m_effectManager->m_persistentItemCountMap = cp.m_persistentItemMap;
        pl->m_varianceValues = cp.m_varianceValues;

        pl->m_calcNonEffectObjects = cp.m_calcNonEffectObjects;
        pl->m_calcNonEffectObjectsSize = cp.m_calcNonEffectObjectsSize;

        while (cp.m_stackSize < m_platformerCheckpoints.size()) {
            // if platformer checkpoint is in stack earlier then don't actually
            // reset
            bool isEarlier = std::any_of(
                m_platformerCheckpoints.begin(),
                m_platformerCheckpoints.end() - 1, [this](const auto& pair) {
                    return pair.second ==
                           this->m_platformerCheckpoints.back().second;
                });

            if (!isEarlier) {
                m_platformerCheckpoints.back().second->m_checkpointActivated =
                    false;
                m_platformerCheckpoints.back().second->resetCheckpoint();
            }

            m_platformerCheckpoints.pop_back();
        }

        auto bot = GrapeEngine::get();
        auto& updater = bot->timeline();
        updater.m_frameOnLastAttempt = cp.m_attemptStartFrame;
        updater.m_timewarpTime = cp.m_timewarpTime;
        updater.setFrame(cp.m_frame - cp.m_attemptStartFrame);
        bot->macro().m_inputIndex = std::min(
            cp.m_replayInputIndex,
            bot->macro().m_actionAtom.m_actions.size());
        bot->macro().getCurrentRandomState() = cp.m_seedState;
        bot->macro().m_shakeRandomState = cp.m_shakeRandomState;
        bot->macro().m_teleportRandomState = cp.m_teleportRandomState;
        if (cp.m_tps != bot->timeline().m_tps->inner()) {
            bot->timeline().m_tps->inner() = cp.m_tps;
            bot->timeline().m_tps->notifyChange();
        }

        this->m_brokenObjects = cp.m_brokenObjects;
        for (auto& obj : this->m_brokenObjects) {
            if (obj) {
                obj->m_isDisabled = true;
                obj->m_isDisabled2 = true;
                obj->setOpacity(0.0f);
            }
        }

        const auto count = std::min(cp.m_advRandStates.size(),
                                    m_advancedRandom.size());
        for (size_t i = 0; i < count; ++i) {
            auto state = cp.m_advRandStates[i];
            *this->m_advancedRandom[i].m_randomState = state;
        }
    }
}

void PracticeFix::saveState(CheckpointObject* obj, uint64_t attemptStartFrame) {
    auto checkpoint = createCheckpoint(obj, attemptStartFrame);

    while (m_storedFrames.size() >= m_maxStoredFrames->inner()) {
        m_storedFrames.front().m_checkpoint->release();
        m_storedFrames.pop_front();
    }

    m_storedFrames.push_back(checkpoint);
}

void PracticeFix::clearStoredFrames() {
    for (auto& frame : m_storedFrames) {
        frame.m_checkpoint->release();
    }
    m_storedFrames.clear();
}

bool PracticeFix::canRestoreState() {
    if (!PlayLayer::get()) return false;
    if (m_storedFrames.size() < 2) return false;

    return true;
}

void PracticeFix::resetWithState(const SavedCheckpoint& state) {
    m_forcedState = const_cast<SavedCheckpoint*>(&state);
    PlayLayer::get()->resetLevel();
    m_forcedState = nullptr;
}

void PracticeFix::restorePreviousFrame(
    std::function<void(CheckpointObject*)> loadFn) {
    if (m_storedFrames.size() < 2) return;

    if (!m_hasDiedNormally) {
        this->dropLastStoredFrame();
    }

    auto& checkpoint = m_storedFrames.back();
    loadFn(checkpoint.m_checkpoint);
    applyCheckpoint(checkpoint);
}

void PracticeFix::dropLastStoredFrame() {
    if (m_storedFrames.empty()) return;
    m_storedFrames.back().m_checkpoint->release();
    m_storedFrames.pop_back();
}

void PracticeFix::saveCurrent(CheckpointObject* obj,
                              uint64_t attemptStartFrame) {
    auto checkpoint = createCheckpoint(obj, attemptStartFrame);
    m_savedCheckpoints.push_back(checkpoint);
}

void PracticeFix::popLatest() {
    if (m_savedCheckpoints.empty()) {
        return;
    }

    m_savedCheckpoints.pop_back();
}

void PracticeFix::applyLatest() {
    if (m_savedCheckpoints.empty()) {
        clearPlatformer(true);
        return;
    }

    auto& checkpoint = m_savedCheckpoints.back();
    applyCheckpoint(checkpoint);
}

void PracticeFix::reseedAdvancedRandom(uint64_t attemptSeed) {
    for (auto& s : m_advancedRandom) {
        *s.m_randomState =
            attemptSeed ^ (static_cast<uint64_t>(s.m_uniqueID) * 2137);
    }
}

void PracticeFix::removeAll() {
    m_brokenObjects.clear();
    m_advancedRandom.clear();
    m_savedCheckpoints.clear();
}

void PracticeFix::clearPlatformer(bool assumeLoaded) {
    while (!m_platformerCheckpoints.empty()) {
        if (assumeLoaded) {
            m_platformerCheckpoints.back().second->m_checkpointActivated =
                false;
            m_platformerCheckpoints.back().second->resetCheckpoint();

            // release
            // m_platformerCheckpoints.top().first->release();
        }

        m_platformerCheckpoints.pop_back();
    }
}

void PracticeFix::updatePlatformerInputs(
    gd::vector<PlayerButtonCommand>& inputs) {
    for (const auto& input : inputs) {
        bool& left = input.m_isPlayer2 ? m_p2Left : m_p1Left;
        bool& right = input.m_isPlayer2 ? m_p2Right : m_p1Right;

        if (input.m_button == PlayerButton::Left) {
            left = input.m_isPush;
        } else if (input.m_button == PlayerButton::Right) {
            right = input.m_isPush;
        }
    }
}

[[maybe_unused]] static std::optional<slc::Action> findLastInputUnused(
    const std::vector<slc::Action>& inputs, uint32_t frame, PlayerButton btn,
    bool p2) {
    const auto& last =
        std::find_if(inputs.rbegin(), inputs.rend(),
                     [frame, btn, p2](const slc::Action& input) {
                         if (input.m_frame < frame &&
                             static_cast<int>(input.m_type) ==
                                 static_cast<int>(btn) &&
                             input.m_player2 == p2) {
                             return true;
                         }

                         return false;
                     });

    if (last == inputs.rend()) {
        return std::nullopt;
    }

    return *last;
}

$execute {
    GrapeEngine::get()->practiceFix().m_maxStoredFrames->handle([](uint32_t& frames) {
        if (frames <= 0 || frames > 100'000) {
            frames = 1;
        }

        auto& storedFrames = GrapeEngine::get()->practiceFix().m_storedFrames;
        while (storedFrames.size() > frames) {
            storedFrames.front().m_checkpoint->release();
            storedFrames.pop_front();
        }
    });
}
