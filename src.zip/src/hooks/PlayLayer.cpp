#include <Geode/Geode.hpp>
#include <filesystem>

#include "assist/autoclicker.hpp"
#include "assist/pathfinder.hpp"
#include "assist/cps.hpp"
#include "assist/hitboxes.hpp"
#include "engine/engine.hpp"
#include "engine/timeline.hpp"
#include "checkpoint/fix.hpp"
#include "label/label.hpp"
#include "render/renderer.hpp"
#include "replay/macro.hpp"
#include "config/config.hpp"
#include "Geode/utils/random.hpp"
#include "Geode/utils/string.hpp"
#include "trajectory/trajectory.hpp"
#ifdef GEODE_IS_WINDOWS
#include "util/midhook.hpp"
#endif
#include "util/profile.hpp"
#ifdef GEODE_IS_MOBILE
#include "ui/touch_overlay.hpp"
#endif

using namespace geode::prelude;

#ifdef GEODE_IS_WINDOWS
#include <Zydis/Zydis.h>
#include <safetyhook.hpp>
#endif

#include <Geode/modify/PlayLayer.hpp>
#include "util/storage.hpp"

struct GrapePlayLayer : Modify<GrapePlayLayer, PlayLayer> {
#ifndef GEODE_IS_WINDOWS
    void postUpdate(float dt) override {
        PlayLayer::postUpdate(dt);
        GrapeEngine::get()->timeline().portableFrameUpdate(this, dt);
    }
#endif

    CheckpointObject* markCheckpoint() {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::markCheckpoint();
        }

        SCOPED_TIMER("createCheckpoint")
        auto cp = createCheckpoint();
        storeCheckpoint(cp);
        return cp;
    }

    void storeCheckpoint(CheckpointObject* obj) {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::storeCheckpoint(obj);
        }

        if (this->m_activatedCheckpoint) {
            obj->retain();
            addToSection(obj->m_physicalCheckpointObject);

            GrapeEngine::get()->practiceFix().m_platformerCheckpoints.push_back(
                {obj, this->m_activatedCheckpoint});
            return;
        }

        obj->retain();
        addToSection(obj->m_physicalCheckpointObject);
        GrapeEngine::get()->practiceFix().saveCurrent(
            obj, GrapeEngine::get()->timeline().m_frameOnLastAttempt);
    }

    void loadFromCheckpoint(CheckpointObject* obj) {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::loadFromCheckpoint(obj);
        }

        auto& pf = GrapeEngine::get()->practiceFix();

        if (pf.m_forcedState) {
            PlayLayer::loadFromCheckpoint(pf.m_forcedState->m_checkpoint);
            pf.applyCheckpoint(*pf.m_forcedState);
            return;
        }

        if (pf.m_loadCheckpoint) {
            pf.restorePreviousFrame(
                [this](auto* cp) { this->PlayLayer::loadFromCheckpoint(cp); });

            pf.m_hasDiedNormally = false;

            return;
        }

        if (pf.m_savedCheckpoints.size() == 0) {
            PlayLayer::loadFromCheckpoint(obj);

            return;
        }

        if (pf.m_shouldLoadPlatformer) {
            PlayLayer::loadFromCheckpoint(
                pf.m_platformerCheckpoints.back().first);

            return;
        }

        auto checkpoint = pf.m_savedCheckpoints.back();
        pf.clearStoredFrames();
        PlayLayer::loadFromCheckpoint(checkpoint.m_checkpoint);

        pf.applyLatest();
    }

    void delayedResetLevel() {

        auto bot = GrapeEngine::get();

        // The pathfinder respawns instantly on death, so this delayed reset --
        // scheduled by the death that already restarted us -- would otherwise
        // restart a run that's already back underway. Skip it once we're alive.
        if (bot->pathfinder().m_enabled->inner() && m_player1 &&
            !m_player1->m_isDead) {
            return;
        }

        if (bot->timeline().m_canDie->inner()) {
            bot->timeline().m_inputIsDeath = true;
        }

        PlayLayer::delayedResetLevel();
    }

    void fakeFullReset() {
        auto winSize = CCDirector::sharedDirector()->getWinSize();
        this->m_gameState.m_totalTime = 0.0;
        this->m_gameState.m_unkDouble3 = 0.0;
        this->m_gameState.m_levelTime = 0.0;
        this->m_player1->m_totalTime = 0.0;
        this->m_player2->m_totalTime = 0.0;
        this->m_attempts = 0;
        this->m_jumps = 0;
        this->m_objectsDeactivated = true;
        this->m_freezeStartCamera = true;

        GrapeEngine::get()->practiceFix().clearPlatformer(true);
        this->resetLevel();
        this->m_attemptLabel->setPosition(CCPoint{
            winSize.width, winSize.width * 0.5f +
                               (float)this->m_gameState.m_cameraPosition.x});
    }

    void fullReset() {
        auto bot = GrapeEngine::get();
        if (!bot->isEnabled()) {
            return PlayLayer::fullReset();
        }

        auto& updater = bot->timeline();

        if (updater.m_canDie->inner()) {
            updater.m_fullReset = true;

            this->fakeFullReset();
        } else if (updater.m_expectsDeath) {
            if (auto ell = this->getChildByID("EndLevelLayer"); ell) {
                ell->removeFromParent();
            }

            this->fakeFullReset();
        } else {
            PlayLayer::fullReset();
            bot->practiceFix().clearPlatformer(true);
            updater.m_frameOnLastAttempt = 0;
        }
    }

    void checkIfResetWasExpected(uint64_t deathFrame) {
        auto bot = GrapeEngine::get();
        auto& replay = bot->macro();
        const auto input = replay.getCurrentQueuedInput();
        if (!input.has_value() ||
            input->m_type != slc::Action::ActionType::Death) {
            return;
        }

#ifdef GEODE_IS_MOBILE
        const bool isDue = input->m_frame <= deathFrame;
#else
        const bool isDue = input->m_frame == deathFrame;
#endif
        if (isDue) {
            replay.advanceInputIndex();
            bot->timeline().m_expectsDeath = true;
        }
    }

    bool isResetIntentional() {
        auto bot = GrapeEngine::get();
        return bot->timeline().m_canDie->inner() ||
               bot->timeline().m_expectsDeath;
    }

    bool handleResetWithCheckpoints(uint64_t deathFrame) {
        auto bot = GrapeEngine::get();
        auto& pf = bot->practiceFix();

        if (this->isResetIntentional()) {
            bot->timeline().m_frameOnLastAttempt = deathFrame + 1;

            if (!pf.m_platformerCheckpoints.empty()) {
                this->m_checkpointArray->addObject(
                    pf.m_platformerCheckpoints.back().first);

                pf.m_shouldLoadPlatformer = true;
                return true;
            }

            return false;
        } else if (!pf.m_savedCheckpoints.empty()) {
            auto lastCheckpoint = pf.m_savedCheckpoints.back();
            this->m_checkpointArray->addObject(lastCheckpoint.m_checkpoint);
            return true;
        } else if (pf.m_forcedState) {
            auto check = pf.m_forcedState;
            this->m_checkpointArray->addObject(check->m_checkpoint);
            return true;
        } else if (pf.m_loadCheckpoint) {
            auto check = pf.m_storedFrames.back();
            this->m_checkpointArray->addObject(check.m_checkpoint);
            return true;
        }

        bot->timeline().m_frameOnLastAttempt = 0;
        pf.clearPlatformer(true);
        return false;
    }

    void updateRandomSeedOnReset() {
        auto bot = GrapeEngine::get();
        auto& rs = bot->macro();
        uint64_t& state = bot->macro().getCurrentRandomState();
        if (!bot->timeline().m_expectsDeath) {
            bot->macro().m_startingSeedThisAttempt =
                bot->macro().m_startingSeed;
        }

        if (bot->isRecording()) {
            if (rs.m_overrideSeed) {
                state = rs.m_overriddenSeed;
            }

            bot->macro().m_startingSeedThisAttempt = state;
            if (bot->practiceFix().m_savedCheckpoints.empty() &&
                !bot->practiceFix().m_loadCheckpoint &&
                !bot->timeline().m_canDie->inner()) {
                state = 214013 * state + 2531011;
                bot->macro().m_startingSeed = state;
                bot->macro().m_startingSeedThisAttempt = state;

                uint64_t varianceState = state;
                for (auto& v : m_varianceValues) {
                    v = (float)(varianceState & 0xFFFF) / 32768.0 - 1.0;
                    varianceState = 214013 * varianceState + 2531011;
                }
            }
        } else {
            bot->macro().getCurrentRandomState() =
                bot->macro().m_startingSeedThisAttempt;

            uint64_t varianceState =
                bot->macro().getCurrentRandomState();
            for (auto& v : m_varianceValues) {
                v = (float)(varianceState & 0xFFFF) / 32768.0 - 1.0;
                varianceState = 214013 * varianceState + 2531011;
            }
        }
    }

    void restoreHoldOnReset(uint64_t deathFrame, bool restoringBackstep) {
        auto bot = GrapeEngine::get();
        bot->practiceFix().updatePlatformerInputs(m_queuedButtons);
        m_queuedButtons.clear();

        if (restoringBackstep) return;

        if (bot->isPlaying()) {
            if (bot->practiceFix().m_savedCheckpoints.empty()) {
                m_player1->releaseAllButtons();
                m_player2->releaseAllButtons();
            }

            if (bot->timeline().m_expectsDeath) {
                while (auto input = bot->macro().getNextQueuedInput()) {
                    if (input->m_frame == deathFrame) {
                        bot->macro().advanceInputIndex();
                    } else {
                        break;
                    }
                }
            }

            auto& canDie = bot->timeline().m_canDie;
            if (canDie->inner()) {
                canDie->inner() = false;
                canDie->notifyChange();
            }
            bot->timeline().m_inputIsDeath = false;
            bot->timeline().m_expectsDeath = false;

            this->processQueuedButtons(0.0, true);

            bot->timeline().m_tpsOverflow = 0.0;
            return;
        }

        // Also covers plain play (mode Stopped), not just recording: this block
        // used to be gated on isRecording(), so with the bot enabled but no
        // macro being recorded nothing ever cleared a jump that was held at the
        // moment of death -- the held state survived the respawn and the player
        // carried on holding by itself. isPlaying() already returned above, so
        // this reads as "recording or plain play".
        if (!bot->isPlaying()) {
            if (bot->timeline().m_canDie->inner()) {
                m_player1->releaseAllButtons();
                m_player2->releaseAllButtons();
                return;
            }

            auto& rs = bot->macro();

            bool p1Holding = this->m_uiLayer->m_p1Jumping ||
                             this->m_uiLayer->m_p1TouchId != -1;
            bool p2Holding = this->m_uiLayer->m_p2Jumping ||
                             this->m_uiLayer->m_p2TouchId != -1;

            auto& pf = bot->practiceFix();
            bool p1Left = pf.m_p1Left;
            bool p2Left = pf.m_p2Left;
            bool p1Right = pf.m_p1Right;
            bool p2Right = pf.m_p2Right;

            if (rs.hasFlippedControls()) {
                std::swap(p1Holding, p2Holding);
            }

            p1Holding |= p2Holding && !m_levelSettings->m_twoPlayerMode;

#define BUTTON_CHECK(varName, button, player)                                  \
    if (p##player##varName !=                                                  \
        this->m_player##player->m_holdingButtons[button]) {                    \
        this->queueButton(button, p##player##varName,                          \
                          rs.playerFlipped(static_cast<bool>(player - 1)), 0); \
    }

            BUTTON_CHECK(Holding, 1, 1)
            if (m_isPlatformer) {
                BUTTON_CHECK(Left, 2, 1)
                BUTTON_CHECK(Right, 3, 1)
            }

            if (m_levelSettings->m_twoPlayerMode) {
                BUTTON_CHECK(Holding, 1, 2)
                if (m_isPlatformer) {
                    BUTTON_CHECK(Left, 2, 2)
                    BUTTON_CHECK(Right, 3, 2)
                }
            }

#undef BUTTON_CHECK

            rs.m_lastInputs.clear();
        }
    }

    void addDeathInput(uint64_t deathFrame) {
        auto bot = GrapeEngine::get();
        if (bot->timeline().m_canDie->inner()) {
            if (bot->timeline().m_inputIsDeath) {
                (void)bot->macro().m_actionAtom.addAction(
                    deathFrame, slc::Action::ActionType::Death,
                    bot->macro().m_startingSeedThisAttempt);
            } else if (bot->timeline().m_fullReset) {
                (void)bot->macro().m_actionAtom.addAction(
                    deathFrame, slc::Action::ActionType::RestartFull,
                    bot->macro().m_startingSeedThisAttempt);
            } else {
                (void)bot->macro().m_actionAtom.addAction(
                    deathFrame, slc::Action::ActionType::Restart,
                    bot->macro().m_startingSeedThisAttempt);
            }
        }
    }

    void intentionalResetDone() {
        auto bot = GrapeEngine::get();
        auto updater = bot->timeline();
        updater.m_canDie->inner() = false;
        updater.m_canDie->notifyChange();
        updater.m_inputIsDeath = false;
        updater.m_expectsDeath = false;
        updater.m_fullReset = false;
        updater.m_tpsOverflow = 0.0;
    }

    void resetLevel() override {
        auto bot = GrapeEngine::get();

        // Drop any leftover noclip tint overlay before the level restarts so
        // it can't linger into the fresh attempt.
        this->removeNoclipTint();

        if (!bot->isEnabled()) {
            m_player1->releaseAllButtons();
            m_player2->releaseAllButtons();

            return PlayLayer::resetLevel();
        }

        const bool restartingCompleted =
            m_hasCompletedLevel || m_levelEndAnimationStarted;
        if (restartingCompleted && !bot->isRecording() &&
            !bot->macro().m_actionAtom.m_actions.empty()) {
            bot->setMode(GrapeEngine::Playing);
        }

        m_practiceMusicSync = true;

        bot->timeline().m_tpsOverflow = 0.0;
        bot->timeline().m_respawnTimer = 2;

        bot->timeline().incrementFrame();

        uint64_t deathFrame = bot->timeline().getFrame();

        this->checkIfResetWasExpected(deathFrame);

        // Let the pathfinder learn from this death before checkpoints are
        // resolved -- if we're stuck it drops the latest checkpoint here so the
        // restore below resumes from an earlier point.
        bot->pathfinder().onDeath(this, deathFrame);

        bool hasAddedCheckpoint = this->handleResetWithCheckpoints(deathFrame);


        bot->timeline().resetFrame();

        bot->hitboxes().clearTrail();
        bot->cps().clearActions();

        this->updateRandomSeedOnReset();


        PlayLayer::resetLevel();

        if (hasAddedCheckpoint) {
            GrapeEngine::get()->practiceFix().m_shouldLoadPlatformer = false;
            this->m_checkpointArray->removeLastObject();

            bot->timeline().m_onlyRefresh = true;
            this->m_extraDelta = 0.0f;
            CCScheduler::get()->update(0.0f);

            bool disableLabels = Renderer::get()->isRecording() &&
                                 !GrapeSettings::get()->renderLabelsWhileRecording;
            bot->labels().update(disableLabels);
            bot->timeline().m_onlyRefresh = false;
        }

        const bool restoredBackstep = bot->practiceFix().m_isBackstep;
        if (!restoredBackstep) {
            bot->macro().onReset(bot->timeline().getFrame());
        }
        bot->autoclicker().reset();

        bot->trajectory().update(this);

        this->restoreHoldOnReset(deathFrame, restoredBackstep);
        this->addDeathInput(deathFrame);

        if (!bot->timeline().m_canDie->inner() && !restoredBackstep) {
            bot->macro().m_flipProcessingInputs = true;
            this->processQueuedButtons(0.0, true);
            bot->macro().m_flipProcessingInputs = false;
        }

        this->intentionalResetDone();

        bot->practiceFix().m_hasDiedNormally = false;
        bot->practiceFix().m_isBackstep = false;

        bot->timeline().breakLoop();
    }

    void updateAttempts() {
        if (GrapeEngine::get()->practiceFix().m_isBackstep) {
            return;
        }

        PlayLayer::updateAttempts();
    }

    void onQuit() {
#ifdef GEODE_IS_MOBILE
        if (auto overlay = TouchOverlay::get()) {
            overlay->hide();
        }
#endif
        if (Renderer::get()->isRecording()) {
            Renderer::get()->signalStop();
        }

        auto bot = GrapeEngine::get();
        bot->timeline().setPaused(false);
        bot->timeline().m_stepOnce->inner() = false;

        bot->trajectory().uninit();
        bot->hitboxes().destroy();

        PlayLayer::onQuit();

        bot->practiceFix().clearStoredFrames();
        bot->practiceFix().removeAll();

        bot->macro().onExit();
    }

    void removeCheckpoint(bool p0) {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::removeCheckpoint(p0);
        }

        if (GrapeEngine::get()->practiceFix().m_savedCheckpoints.empty()) {
            return;
        }

        auto checkpoint = GrapeEngine::get()->practiceFix().m_savedCheckpoints.back();

        auto obj = checkpoint.m_checkpoint->m_physicalCheckpointObject;
        this->removeObjectFromSection(obj);

        auto* glowSprite = obj->m_glowSprite;
        if (glowSprite) {
            glowSprite->release();
            glowSprite->removeMeAndCleanup();
            glowSprite = nullptr;
        }

        obj->removeMeAndCleanup();

        checkpoint.m_checkpoint->release();

        GrapeEngine::get()->practiceFix().popLatest();
    }

    void removeAllCheckpoints() override {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::removeAllCheckpoints();
        }

        if (GrapeEngine::get()->timeline().m_fullReset) return;

        while (!GrapeEngine::get()->practiceFix().m_savedCheckpoints.empty()) {
            removeCheckpoint(false);
        }
    }

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!GrapeEngine::get()->isEnabled()) {
            return PlayLayer::init(level, useReplay, dontCreateObjects);
        }

        auto bot = GrapeEngine::get();
        bot->practiceFix().clearStoredFrames();
        if (bot->trajectory().exists()) {
            bot->trajectory().uninit();
        }
        bot->practiceFix().clearPlatformer(
            false);

        auto renderer = Renderer::get();
        if (renderer->m_shouldStart) {
            FMODAudioEngine::sharedEngine()->stopAllMusic(true);
            FMODAudioEngine::sharedEngine()->stopAllEffects();
        }

        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) {
            return false;
        }

        m_clickOnSteps = false;
        m_clickBetweenSteps = false;

        bot->trajectory().init(this);
        bot->hitboxes().init(this);
        bot->hitboxes().clearTrail();
        bot->timeline().m_frameOnLastAttempt = 0;
        bot->timeline().m_lastTfp = 0.0f;
        bot->timeline().setPaused(false);
        bot->timeline().m_stepOnce->inner() = false;
        bot->labels().m_requiresRefresh = true;

        if (GrapeSettings::get()->autoMacroName)
            bot->macro().m_replayName = geode::utils::string::replace(
                GrapeSettings::get()->macroNameTemplate, "%name%",
                level->m_levelName);

        return true;
    }

    void conditionalDestroyPlayer(PlayerObject* player,
                                  GameObject* gameObject) {
        if (gameObject == m_anticheatSpike) {
            return PlayLayer::destroyPlayer(player, gameObject);
        }

        auto bot = GrapeEngine::get();

        using N = FrameEngine::NoclipType;
        bool shouldDie = (bot->timeline().m_noclipType == N::Player1 &&
                          (player == m_player2)) ||
                         (bot->timeline().m_noclipType == N::Player2 &&
                          (player == m_player1));

        if (!bot->timeline().m_noclip->inner() || shouldDie) {
            // Real death: clear any in-flight noclip tint so it doesn't flash
            // back at full opacity over the death animation.
            this->removeNoclipTint();
            return PlayLayer::destroyPlayer(player, gameObject);
        }

        auto* settings = GrapeSettings::get();
        if (settings->noclipTintEnabled) {
            constexpr auto tintID = "noclip-tint"_spr;
            auto* tint =
                typeinfo_cast<CCLayerColor*>(this->getChildByID(tintID));
            auto& source = settings->noclipTintColor;
            const ccColor3B rgb = {
                static_cast<GLubyte>(std::clamp(source[0], 0.f, 1.f) * 255.f),
                static_cast<GLubyte>(std::clamp(source[1], 0.f, 1.f) * 255.f),
                static_cast<GLubyte>(std::clamp(source[2], 0.f, 1.f) * 255.f)};
            const GLubyte opacity = static_cast<GLubyte>(
                std::clamp(settings->noclipTintOpacity, 0.0, 1.0) * 255.0);
            if (tint) {
                // Still fading, so this is the same pass-through rather than a
                // new death: the game calls destroyPlayer on every frame the
                // hitbox overlaps the hazard, and restarting the fade on each
                // of those snapped the overlay back to full opacity -- the
                // brief second flash. Leave the running fade alone; it removes
                // itself at the end, so the next death tints normally.
                if (tint->numberOfRunningActions() > 0) return;
                // No actions left but still parented: the fade was cut short
                // (CCActionManager::update is skipped on refresh frames), so
                // re-animate this node rather than returning -- otherwise a
                // stranded overlay would sit on screen and suppress every
                // future tint.
            } else {
                auto size = CCDirector::get()->getWinSize();
                tint = CCLayerColor::create({rgb.r, rgb.g, rgb.b, 0},
                                            size.width, size.height);
                tint->setID(tintID);
                this->addChild(tint, 100000);
            }

            tint->setColor(rgb);
            tint->setOpacity(opacity);

            const float duration = static_cast<float>(
                std::clamp(settings->noclipTintTime, 0.0, 10.0));
            tint->runAction(CCSequence::create(
                CCDelayTime::create(duration * .35f),
                CCFadeOut::create(std::max(.01f, duration * .65f)),
                geode::cocos::CallFuncExt::create(
                    [tint] { tint->removeFromParent(); }),
                nullptr));
        }
    }

    // Remove any lingering noclip tint overlay so it can't reappear (e.g. at
    // full opacity) when the player actually dies or the level resets.
    void removeNoclipTint() {
        constexpr auto tintID = "noclip-tint"_spr;
        if (auto* tint =
                typeinfo_cast<CCLayerColor*>(this->getChildByID(tintID))) {
            tint->stopAllActions();
            tint->removeFromParent();
        }
    }

    void destroyPlayer(PlayerObject* player, GameObject* gameObject) override {
        auto bot = GrapeEngine::get();

        if (!bot->trajectory().hasDied(player)) {
            this->conditionalDestroyPlayer(player, gameObject);

            if (bot->timeline().m_preventDeath->inner() &&
                !bot->timeline().m_noclip->inner() &&
                gameObject != m_anticheatSpike) {
                bot->timeline().backwardsStep();

                if (bot->timeline().m_autoFlipOnDeath->inner() &&
                    !bot->practiceFix().m_isBackstep) {
                    if (player == m_player1) {
                        this->queueButton(1, !player->m_jumpBuffered, false,
                                          0.0);
                    } else {
                        this->queueButton(1, !player->m_jumpBuffered, true,
                                          0.0);
                    }

                    bot->timeline().setPaused(false);
                }
            }

            if (!bot->practiceFix().m_loadCheckpoint &&
                !bot->practiceFix().m_isBackstep) {
                bot->practiceFix().m_hasDiedNormally = true;
            }
        }
    }

    void pauseGame(bool p0) {
        m_gameState.m_pauseCounter = 0;

        PlayLayer::pauseGame(p0);
    }

    void updateVisibility(float dt) override {
        auto& updater = GrapeEngine::get()->timeline();
        if (updater.m_extrapolateFrames->inner()) {
            dt = CCDirector::get()->getDeltaTime();
        }

#ifdef GEODE_IS_MOBILE
        if (auto overlay = TouchOverlay::get()) {
            overlay->updateVisibility();
        }
#endif

        PlayLayer::updateVisibility(dt);
        if (updater.m_layoutMode->inner()) {
            constexpr std::array<int, 5> colors = {1000, 1001, 1009, 1013,
                                                   1014};
            for (const int color : colors) {
                if (ColorAction* action =
                        m_effectManager->getColorAction(color)) {
                    switch (color) {
                        case 1000: {
                            auto& col = GrapeSettings::get()->layoutBgColor;
                            action->m_color = {
                                static_cast<GLubyte>(col[0] * 255),
                                static_cast<GLubyte>(col[1] * 255),
                                static_cast<GLubyte>(col[2] * 255),
                            };
                            break;
                        }
                        case 1001:
                        case 1009: {
                            auto& col = GrapeSettings::get()->layoutGroundColor;
                            action->m_color = {
                                static_cast<GLubyte>(col[0] * 255),
                                static_cast<GLubyte>(col[1] * 255),
                                static_cast<GLubyte>(col[2] * 255),
                            };
                            break;
                        }
                        default: {
                            action->m_color = {40, 125, 255};
                        }
                    }
                }
            }
        }

        GrapeEngine::get()->hitboxes().draw(this);
    }

    void levelComplete() {
        PlayLayer::levelComplete();

        auto bot = GrapeEngine::get();
        auto& replay = bot->macro();
        if (!replay.m_autosaveAtLevelEnd->inner()) return;

        if (replay.m_replayName.empty()) replay.m_replayName = "autosave";
        auto path = replay.getCurrentPath();
        if (std::filesystem::exists(path)) {
            replay.createBackup();
        } else {
            replay.save(path, true);
        }
    }

    void setupHasCompleted() {
        auto bot = GrapeEngine::get();
        if (!bot->isEnabled()) {
            return PlayLayer::setupHasCompleted();
        }

        Renderer* renderer = Renderer::get();
        renderer->startIfQueued();

        return PlayLayer::setupHasCompleted();
    }

    void addObject(GameObject* obj) {
        if (!GrapeEngine::get()->isEnabled() ||
            !GrapeEngine::get()->timeline().m_layoutMode->inner()) {
            return PlayLayer::addObject(obj);
        }

        static const std::unordered_set<int> OTHER_OBJECT_IDS = {
            32,   33,   1006, 1007, 29,   30,   104,  105,  221,  717,
            718,  743,  744,  899,  915,  2903, 2904, 2905, 2907, 2909,
            2910, 2911, 2912, 2913, 2914, 2915, 2916, 2917, 2919, 2920,
            2921, 2922, 2923, 2924, 3029, 3030, 3031, 3606, 3612};

        if (OTHER_OBJECT_IDS.contains(obj->m_objectID)) {
            obj->m_isHide = true;
        } else {
            obj->setOpacity(255);
            obj->m_isHide = false;
            obj->m_hasNoGlow = true;
            obj->m_activeMainColorID = -1;
            obj->m_activeDetailColorID = -1;
            obj->m_baseUsesHSV = false;
            obj->m_detailUsesHSV = false;
            obj->m_isDontFade = true;
            obj->m_isDontEnter = true;
        }

        PlayLayer::addObject(obj);
    }
};

#ifdef GEODE_IS_WINDOWS
constexpr int QUEUE_CHECKPOINT_OFFSET = 0x4ce060;

void PlayLayer_queueCheckpoint(void* unk, void* unk2) {
    if (!GrapeEngine::get()->isEnabled()) {
        return reinterpret_cast<void (*)(void*, void*)>(
            geode::base::get() + QUEUE_CHECKPOINT_OFFSET)(unk, unk2);
    }

    auto pl = PlayLayer::get();

    if (!pl) return;
    // Was only checking m_isDead, and dereferenced m_player2 unconditionally.
    if (checkpointPlacementBlocked(pl)) {
        return;
    }

    // Re-check on the way out: the placement is deferred to a frozen frame, so
    // the player can die between queueing it and it actually running.
    GrapeEngine::get()->timeline().scheduleFrozenFunction([pl](float) {
        if (checkpointPlacementBlocked(pl)) return;
        pl->markCheckpoint();
    });
}

$execute {
    (void)Mod::get()->hook(
        reinterpret_cast<void*>(geode::base::get() + QUEUE_CHECKPOINT_OFFSET),
        &PlayLayer_queueCheckpoint, "PlayLayer::queueCheckpoint",
                           tulip::hook::TulipConvention::Default);
}
#endif

#ifdef GEODE_IS_WINDOWS
static void resetLevelSeedMidhook(SafetyHookContext&) {
    if (!GrapeEngine::get()->isEnabled()) {
        return;
    }

    GrapeEngine::get()->macro().getCurrentRandomState() =
        GrapeEngine::get()->macro().m_startingSeedThisAttempt;
    GrapeEngine::get()->macro().m_shakeRandomState =
        GrapeEngine::get()->macro().m_startingSeedThisAttempt & 0x7FFF;
    GrapeEngine::get()->practiceFix().reseedAdvancedRandom(
        GrapeEngine::get()->macro().m_startingSeedThisAttempt);
}

$execute {
    util::midhook(geode::base::get() + 0x3b90fb, "resetLevelSeed",
                  resetLevelSeedMidhook);
}
#endif

$execute {

    GrapeEngine::get()->timeline().m_tps->handle([](double& tps) {
        if (tps <= 0.0) {
            tps = 240.0;
        }

        if (auto pl = GJBaseGameLayer::get(); pl) {
#ifdef GEODE_IS_MOBILE
            GrapeEngine::get()->timeline().scheduleFrozenFunction([](float) {
                auto* pl = GJBaseGameLayer::get();
                if (!pl) return;
                if (auto t = GrapeEngine::get()->trajectory().unsafeInner(); t) {
                    t->invalidateCache();
                }
                GrapeEngine::get()->trajectory().update(pl);
            });
#else
            GrapeEngine::get()->timeline().scheduleFrozenFunction([pl](float) {
                if (auto t = GrapeEngine::get()->trajectory().unsafeInner(); t) {
                    t->invalidateCache();
                }
                GrapeEngine::get()->trajectory().update(pl);
            });
#endif
        }
    });
}
